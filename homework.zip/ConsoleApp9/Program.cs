﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // Set an array of real numbers
        double[] nums = { 3.4, 7.8, 22.1, 2.3, 78.6 };

        // Find the difference between the maximal and minimal elements
        double min = nums[0];
        double max = nums[0];
        foreach (double num in nums)
        {
            if (num < min)
            {
                min = num;
            }
            if (num > max)
            {
                max = num;
            }
        }
        double diff = max - min;

        // Display the results
        Console.WriteLine("Array: [" + string.Join(", ", nums) + "]");
        Console.WriteLine("Difference between maximal and minimal elements: " + diff);
    }
}
