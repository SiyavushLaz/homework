﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // Generate an array of 10 random numbers
        int[] nums = new int[10];
        Random rand = new Random();
        for (int i = 0; i < nums.Length; i++)
        {
            nums[i] = rand.Next(100);
        }

        // Find the sum of elements at odd positions
        int oddSum = 0;
        for (int i = 1; i < nums.Length; i += 2)
        {
            oddSum += nums[i];
        }

        // Display the results
        Console.WriteLine("Random array: [" + string.Join(", ", nums) + "]");
        Console.WriteLine("Sum of elements at odd positions: " + oddSum);
    }
}
