﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // Generate an array of 10 random positive three-digit numbers
        int[] nums = new int[10];
        Random rand = new Random();
        for (int i = 0; i < nums.Length; i++)
        {
            nums[i] = rand.Next(100, 1000);
        }

        // Count the number of even numbers in the array
        int evenCount = 0;
        foreach (int num in nums)
        {
            if (num % 2 == 0)
            {
                evenCount++;
            }
        }

        // Display the results
        Console.WriteLine("Random array: [" + string.Join(", ", nums) + "]");
        Console.WriteLine("Number of even numbers: " + evenCount);
    }
}
